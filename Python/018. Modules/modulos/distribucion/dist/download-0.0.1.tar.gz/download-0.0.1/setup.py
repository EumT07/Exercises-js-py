"""
Importar de septuptools; para poder crear nuestro paquete distribuible

"""

from unicodedata import name
from setuptools import setup

setup(
    name="download",
    version="0.0.1",
    description="Primer paquete de distribucion",
    author="Eublan Mata",
    author_email="eublanmata@gmail.com",
    url="http://eublanmata.com",
    scripts=[],
    packages=["paquete","paquete.A","paquete.B"]
)

"""

Para crearlo escribimos lo siguiente:
python setup.py sdist

"""