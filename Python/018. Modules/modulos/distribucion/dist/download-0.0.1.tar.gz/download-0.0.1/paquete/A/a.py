def a(name,lastName,age):
    print(f"Hola tu nombre es: {name} {lastName} edad: {age} años")