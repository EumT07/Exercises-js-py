class Hola:
    def __init__(self):
        print("Bienvenido seas a nuestro primer ensayo de paquetes distribuibles")